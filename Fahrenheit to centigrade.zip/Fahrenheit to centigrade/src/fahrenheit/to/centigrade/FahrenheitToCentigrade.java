/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fahrenheit.to.centigrade;
import java.util.Scanner;

/**
 *
 * @author hi
 */
public class FahrenheitToCentigrade {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      
//     C = 5*(F-32)/9
       int f, c;
        Scanner sc = new Scanner(System.in);
       System.out.println("درجه حرارت فارنهایت را وارد کنید: ");
       f = sc.nextInt();
        c = 5*(f-32)/9;
        System.out.println("حرارت سانتیگراد " +(c)+ " است : ");
    }
    
}
